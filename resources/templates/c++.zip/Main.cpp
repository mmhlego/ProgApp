#include <iostream>

using namespace std;

int main() {
  /*
  * Code goes here
  */
  return 0;
}
